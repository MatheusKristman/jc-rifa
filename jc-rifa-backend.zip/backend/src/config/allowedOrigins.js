const allowedOrigins = ["https://jc-rifa.onrender.com"];

module.exports = allowedOrigins;
